#include<iostream>
#include<string>
#include<iomanip>

using namespace std;
//variables set in place for hours, minutes and seconds
int hours12, hours24, minutes, seconds;
string ampm;
//function that adds an hour to the clock for each addhour() call
void addHour() {
	hours12 = hours12 + 1;
	//Switches the clock to AM or PM as described by the time passing 12
	if (hours12 > 12) {
		hours12 = hours12 - 12;
		if (ampm == "AM")
			ampm = "PM";
		else
			ampm = "AM";
	}
}
//Describes how minutes will be used, adding 1 hour when minutes is equal to 60
void addMinute() {
	minutes = minutes + 1;
	if (minutes > 59) {
		minutes = 0;
		addHour();

	}
}
//Describes how seconds will be used, adding 1 minute when seconds is equal to 60
void addSecond() {
	seconds = seconds + 1;
	if (seconds > 59) {
		seconds = 0;
		addMinute();
	}
}

// call for main function
int main() {
	//variable to set a user's choice into place
	int choice = 0;
	//setting the clock to 1 AM as a starting point
	hours12 = 1;
	minutes = 0;
	seconds = 0;
	ampm = "AM";
	//start of loop for user input
	while (1) {
		//calculating the 24 hours clock change from the 12 hour clock by adding 12 without going over 24 hours
		if (ampm == "PM") {
			hours24 = hours12 + 12;
			if (hours24 > 24) {
				hours24 = hours24 - 24;
			}
		}
		else {
			hours24 = hours12;
		}
		
		//printing of the clock, with both times being visible at the top in between boxes
		cout << "****************************\t\t****************************\n";
		cout << "*       12-Hour Clock      *\t\t*       24-Hour Clock      *\n";
		cout << "----------------------------            ----------------------------\n";
		cout << "*        " << setw(2) << setfill('0') << hours12 << ":" << setw(2) << setfill('0') << minutes << ":" << setw(2) << setfill('0') << seconds << " " << ampm << "       *";
		cout << "\t\t*        " << setw(2) << setfill('0') << hours24 << ":" << setw(2) << setfill('0') << minutes << ":" << setw(2) << setfill('0') << seconds << " " << ampm << "       *\n";
		cout << "****************************\t\t****************************\n";
		//printing the options for the user to choose from with an exit option to break loop
		cout << "\n\n***********************\n";
		cout << "* [1]- Add One Hour   *\n";
		cout << "* [2]- Add One Minute *\n";
		cout << "* [3]- Add One Second *\n";
		cout << "* [4]- Exit Program   *\n";
		cout << "***********************\n";
		cout << "Please Pick from the Following Options by Typing in the Number: ";
		cin >> choice;
		//telling the system what to do when user picks a choice
		if (choice == 1) {
			//function to add an hour when user picks [1]
			addHour();
		}
		else if (choice == 2) {
			//function to add a minute when user picks [2]
			addMinute();
		}
		else if (choice == 3) {
			//function to add second when user pics [3]
			addSecond();
		}
		else if (choice == 4) {
			//exit call for program to end if user picks [4]
			cout << "Exiting...";
			break;
		}
		else {
			//error message if the user's input was not valid
			cout << "Invalid";
		}
	}
}